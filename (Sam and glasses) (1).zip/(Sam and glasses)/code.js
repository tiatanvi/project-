var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["656b172f-84b5-412e-bfc4-9fcf115926c7","c5025a4e-0472-4ebe-8e0b-3faec973e00d","cec21d5c-f61a-49d4-8593-cbd885c33360","a0251a3f-ba15-4bf1-9bdb-ba025c96e4d3","b6d228fd-9562-415d-a973-f204c52b1405","dc49a631-deca-43aa-97fb-3380d982c175"],"propsByKey":{"656b172f-84b5-412e-bfc4-9fcf115926c7":{"name":"bunny1_ready_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qK4aRpIy7j6cT3CbOFjSpMeU4KhS0KZM/category_animals/bunny1_ready.png","frameSize":{"x":120,"y":191},"frameCount":1,"looping":true,"frameDelay":2,"version":"qK4aRpIy7j6cT3CbOFjSpMeU4KhS0KZM","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":120,"y":191},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qK4aRpIy7j6cT3CbOFjSpMeU4KhS0KZM/category_animals/bunny1_ready.png"},"c5025a4e-0472-4ebe-8e0b-3faec973e00d":{"name":"bunny1_hurt_1","sourceUrl":"assets/api/v1/animation-library/gamelab/iAgEA.T3Kkj8V1dyHUrOXAErKxRZM9Us/category_animals/bunny1_hurt.png","frameSize":{"x":150,"y":174},"frameCount":1,"looping":true,"frameDelay":2,"version":"iAgEA.T3Kkj8V1dyHUrOXAErKxRZM9Us","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":150,"y":174},"rootRelativePath":"assets/api/v1/animation-library/gamelab/iAgEA.T3Kkj8V1dyHUrOXAErKxRZM9Us/category_animals/bunny1_hurt.png"},"cec21d5c-f61a-49d4-8593-cbd885c33360":{"name":"blue_hoodie_backpack_1","sourceUrl":"assets/api/v1/animation-library/gamelab/zPUFCzpi9NNCKu799uw5h7NO1Y13PEFP/category_people/blue_hoodie_backpack.png","frameSize":{"x":119,"y":383},"frameCount":1,"looping":true,"frameDelay":2,"version":"zPUFCzpi9NNCKu799uw5h7NO1Y13PEFP","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":119,"y":383},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zPUFCzpi9NNCKu799uw5h7NO1Y13PEFP/category_people/blue_hoodie_backpack.png"},"a0251a3f-ba15-4bf1-9bdb-ba025c96e4d3":{"name":"blue_dress_1","sourceUrl":"assets/api/v1/animation-library/gamelab/KUnlL6hGJRFxIL.OpIiREaXPfuGn6ufz/category_people/blue_dress.png","frameSize":{"x":132,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"KUnlL6hGJRFxIL.OpIiREaXPfuGn6ufz","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":132,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/KUnlL6hGJRFxIL.OpIiREaXPfuGn6ufz/category_people/blue_dress.png"},"b6d228fd-9562-415d-a973-f204c52b1405":{"name":"blue_shirt_hands_behind_1","sourceUrl":"assets/api/v1/animation-library/gamelab/MesNu2ZiuhY9vAovUeL3Vzq.MZgpRfKD/category_people/blue_shirt_hands_behind.png","frameSize":{"x":136,"y":386},"frameCount":1,"looping":true,"frameDelay":2,"version":"MesNu2ZiuhY9vAovUeL3Vzq.MZgpRfKD","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":136,"y":386},"rootRelativePath":"assets/api/v1/animation-library/gamelab/MesNu2ZiuhY9vAovUeL3Vzq.MZgpRfKD/category_people/blue_shirt_hands_behind.png"},"dc49a631-deca-43aa-97fb-3380d982c175":{"name":"blue_sweater_book_1","sourceUrl":"assets/api/v1/animation-library/gamelab/zuK0iqmMs6NqMyZjWzm_qNDdOe2_AuSZ/category_people/blue_sweater_book.png","frameSize":{"x":119,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"zuK0iqmMs6NqMyZjWzm_qNDdOe2_AuSZ","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":119,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zuK0iqmMs6NqMyZjWzm_qNDdOe2_AuSZ/category_people/blue_sweater_book.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 5;
var car1, car2, car3,car4;
var boundary1, boundary2;
var sam;

  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);
  
  sam = createSprite(20,190,13,13);
  sam.shapeColor = "green";
  sam.setAnimation("bunny1_ready_1");
  sam.scale=0.2;
  
  car1 = createSprite(100,130,10,10);
  car1.shapeColor = "red";
  car1.setAnimation("blue_hoodie_backpack_1");
  car1.scale=0.11;
  
  car2 = createSprite(215,130,10,10);
  car2.shapeColor = "red";
  car2.setAnimation("blue_dress_1");
  car2.scale=0.11;
  
  car3 = createSprite(165,250,10,10);
  car3.shapeColor = "red";
  car3.setAnimation("blue_sweater_book_1");
  car3.scale=0.11;
  
  
  car4 = createSprite(270,250,10,10);
  car4.shapeColor = "red";
  car4.setAnimation("blue_shirt_hands_behind_1");
  car4.scale=0.11;
  
 
//add the velocity to make the car move.
 car1.velocityY=8;
 car2.velocityY=-8;
 car3.velocityY=8;
 car4.velocityY=-8;

function draw() {
   background("lightYellow");
   textSize(22);
   strokeWeight(2);
   stroke("darkRed");
  text("Lives: " + life,200,100);
  strokeWeight(0);
  fill("lightGreen");
  rect(0,120,52,140);
  fill("lightGreen");
  rect(345,120,52,140);
  
// create bounceoff function to make the car bounceoff the boundaries
 createEdgeSprites();
 
 car1.bounceOff(boundary1);
 car1.bounceOff(boundary2);
 
 car2.bounceOff(boundary1);
 car2.bounceOff(boundary2);
 
 car3.bounceOff(boundary1);
 car3.bounceOff(boundary2);
 
 car4.bounceOff(boundary1);
 car4.bounceOff(boundary2);
 
 
 
//Add the condition to make the sam move left and right

if (keyDown("RIGHT")) 
{ sam.x=sam.x+3;

}
if (keyDown("LEFT")) 
{ sam.x=sam.x-3;
  
}


//Add the condition to reduce the life of sam if it touches the car.

if (sam.isTouching(car1)|| sam.isTouching(car2)|| sam.isTouching(car3) || sam.isTouching(car4)) 
{ life=life-1;
  sam.x=20;
  sam.y=198;
  sam.setAnimation("bunny1_hurt_1");
}

if (life===0)
{ textSize(20);
  stroke("black");
  strokeWeight(2);
  text("YOU LOST", 108,294);
car1.setVelocity(0,0);
car2.setVelocity(0,0);
car3.setVelocity(0,0);
car4.setVelocity(0,0);

}

  
 drawSprites();
}








// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
